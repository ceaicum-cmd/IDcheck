---
name: landmark-provider
description: Use to extract pose landmarks (especially pose_world_landmarks) from images using MediaPipe. Required before running detailed body analysis with mk2-metricforge-analyzer. Activate on extract landmarks, get pose landmarks, prepare for body analysis, or landmark extraction.
---

# Landmark Provider

## Purpose

This skill handles **landmark extraction** from images — a required step before using `mk2-metricforge-analyzer`.

The MK2 + MetricForge system works best with **`pose_world_landmarks`** (metric 3D coordinates in meters), not just 2D image landmarks.

## When to Use

Use this skill when:
- You need to prepare an image for body/glute analysis
- The user uploads an image and wants "MK2 analysis" or "MetricForge report"
- You need reliable 3D world landmarks for accurate angle and projection calculations

## Recommended Approach

### Preferred Method: MediaPipe Tasks API (PoseLandmarker)

Use `pose_world_landmarks` whenever possible because:
- They are in **real metric units** (meters)
- Much more stable and accurate for **MetricForge** angle calculations (α, β, γ, δ, etc.)
- Required for high-quality glute projection and pelvic metrics

### Workflow

1. Extract landmarks from the input image(s)
2. Prefer `pose_world_landmarks` over regular `pose_landmarks`
3. Pass the landmarks to `mk2-metricforge-analyzer` or `full_body_analyzer.py`
4. Generate the structured Body Sheet report

## Key Points

- Always try to obtain **`pose_world_landmarks`**
- If using the Python script in `scripts/landmark_provider.py`, make sure MediaPipe Tasks is available. Model files (.task) are stored in `models/` inside this skill directory for self-containment.
- For best results with MetricForge, world landmarks + known height or reference object calibration is recommended
- You can also use the landmarker module from `body_analysis_mk2_precision` as fallback

## Integration with mk2-metricforge-analyzer

Typical flow:
1. User uploads image → activate `landmark-provider`
2. Extract `pose_world_landmarks`
3. Automatically or manually pass landmarks to `mk2-metricforge-analyzer`
4. Generate full report with celebrity references and identity lock

This two-skill combination (`landmark-provider` + `mk2-metricforge-analyzer`) enables end-to-end body analysis from raw image to professional report.
