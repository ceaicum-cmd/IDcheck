# landmark-provider/scripts/landmark_provider.py
"""
Landmark Provider v2.2
Provides optimized MediaPipe landmark extraction for face and pose.
"""

import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision, BaseOptions
import numpy as np
from typing import Dict, Any, Optional
import cv2
import os

# ====================== CONFIG ======================
FACE_MODEL_PATH = "/home/workdir/.grok/skills/landmark-provider/models/face_landmarker.task"
POSE_MODEL_PATH = "/home/workdir/.grok/skills/landmark-provider/models/pose_landmarker_full.task"

USE_GPU = False  # Hardcoded to CPU only (forced)
MIN_DETECTION_CONFIDENCE = 0.5

# ====================== SINGLETON LANDMARKERS ======================
_face_landmarker = None
_pose_landmarker = None

def _get_face_landmarker():
    global _face_landmarker
    if _face_landmarker is None:
        delegate = BaseOptions.Delegate.CPU  # Forced CPU only
        base_options = python.BaseOptions(model_asset_path=FACE_MODEL_PATH, delegate=delegate)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options,
            output_facial_transformation_matrixes=True,
            running_mode=vision.RunningMode.IMAGE,
            min_face_detection_confidence=MIN_DETECTION_CONFIDENCE,
        )
        _face_landmarker = vision.FaceLandmarker.create_from_options(options)
    return _face_landmarker

def _get_pose_landmarker(enable_segmentation: bool = True):
    global _pose_landmarker
    if _pose_landmarker is None:
        delegate = BaseOptions.Delegate.CPU  # Forced CPU only
        base_options = python.BaseOptions(model_asset_path=POSE_MODEL_PATH, delegate=delegate)
        options = vision.PoseLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.IMAGE,
            min_pose_detection_confidence=MIN_DETECTION_CONFIDENCE,
            output_segmentation_masks=enable_segmentation,
        )
        _pose_landmarker = vision.PoseLandmarker.create_from_options(options)
    return _pose_landmarker

# ====================== FAST IMAGE LOADING ======================
def _load_image_fast(image_path: str):
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not read image: {image_path}")
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    if len(img_rgb.shape) == 3 and img_rgb.shape[2] == 4:
        img_rgb = cv2.cvtColor(img_rgb, cv2.COLOR_RGBA2RGB)
    img_rgb = np.ascontiguousarray(img_rgb, dtype=np.uint8)
    return mp.Image(image_format=mp.ImageFormat.SRGB, data=img_rgb)

# ====================== HAND LANDMARKER ======================
_hand_landmarker = None

def _get_hand_landmarker():
    global _hand_landmarker
    if _hand_landmarker is None:
        delegate = BaseOptions.Delegate.CPU  # Forced CPU only
        base_options = python.BaseOptions(model_asset_path="/home/workdir/.grok/skills/landmark-provider/models/hand_landmarker.task", delegate=delegate)
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            num_hands=2,
            min_hand_detection_confidence=0.5,
            min_hand_presence_confidence=0.5,
        )
        _hand_landmarker = vision.HandLandmarker.create_from_options(options)
    return _hand_landmarker

# ====================== PUBLIC API ======================
def extract_landmarks(
    image_path: str, 
    use_gpu: bool = True, 
    profile_mode: bool = False, 
    detect_hands: bool = False,
    enable_segmentation: bool = True          # Segmentation activat by default
) -> Dict[str, Any]:
    """
    Extract face, pose and optionally hand landmarks + segmentation.
    
    Args:
        profile_mode: Better detection for side profiles.
        detect_hands: Enable hand landmark extraction.
        enable_segmentation: Return body segmentation mask (activat by default).
    """
    global USE_GPU, MIN_DETECTION_CONFIDENCE
    USE_GPU = use_gpu

    if profile_mode:
        MIN_DETECTION_CONFIDENCE = 0.25

    image = _load_image_fast(image_path)

    face_result = _get_face_landmarker().detect(image)
    pose_result = _get_pose_landmarker(enable_segmentation=enable_segmentation).detect(image)

    result = {
        "face": _process_face_result(face_result),
        "pose": _process_pose_result(pose_result),
        "inference_device": "GPU" if USE_GPU else "CPU",
        "profile_mode_used": profile_mode
    }

    if detect_hands:
        hand_result = _get_hand_landmarker().detect(image)
        result["hands"] = _process_hand_result(hand_result)

    # === Procesare mască de segmentare ===
    if enable_segmentation and hasattr(pose_result, 'segmentation_masks') and pose_result.segmentation_masks:
        result["has_segmentation_mask"] = True
        try:
            mask = pose_result.segmentation_masks[0]
            mask_array = mask.numpy_view()

            result["segmentation"] = {
                "mask_shape": mask_array.shape,
                "person_pixels": int(np.sum(mask_array > 0.5)),
                "total_pixels": int(mask_array.size),
                "person_ratio": round(float(np.sum(mask_array > 0.5)) / mask_array.size, 4)
            }
        except Exception as e:
            result["segmentation_error"] = str(e)

    return result

def _process_hand_result(result) -> Dict[str, Any]:
    if not result.hand_landmarks:
        return {"detected": False, "hands": []}
    
    hands = []
    for i, hand_landmarks in enumerate(result.hand_landmarks):
        hands.append({
            "handedness": result.handedness[i][0].category_name if result.handedness else "Unknown",
            "landmarks": [{"x": lm.x, "y": lm.y, "z": lm.z} for lm in hand_landmarks]
        })
    
    return {
        "detected": True,
        "num_hands": len(hands),
        "hands": hands
    }

def _process_face_result(result) -> Dict[str, Any]:
    if not result.face_landmarks:
        return {"detected": False}
    return {
        "detected": True,
        "landmarks": [{"x": lm.x, "y": lm.y, "z": lm.z} for lm in result.face_landmarks[0]],
        "landmark_count": len(result.face_landmarks[0])
    }

def _process_pose_result(result) -> Dict[str, Any]:
    if not result.pose_landmarks:
        return {"detected": False}

    # Always return world_landmarks as list (never None)
    world_landmarks = []
    has_world_landmarks = False

    if result.pose_world_landmarks:
        world_landmarks = [{"x": lm.x, "y": lm.y, "z": lm.z} for lm in result.pose_world_landmarks[0]]
        has_world_landmarks = True

    return {
        "detected": True,
        "landmarks": [{"x": lm.x, "y": lm.y, "z": lm.z, "visibility": lm.visibility} for lm in result.pose_landmarks[0]],
        "world_landmarks": world_landmarks,
        "has_world_landmarks": has_world_landmarks,
        "landmark_count": len(result.pose_landmarks[0])
    }

def clear_landmarkers():
    global _face_landmarker, _pose_landmarker
    _face_landmarker = None
    _pose_landmarker = None
