#!/usr/bin/env python3
"""
Full Body Analyzer - Unified Wrapper
Combines:
- Landmark Provider (MediaPipe Tasks)
- UnifiedBodyAnalyzer
- MK2 Precision Grok
- MetricForge (Glute Angles)

Designed to be the single easy entry point for analysis in Grok chat.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import Dict, Any, Optional
import json

# ============================================================
# Self-contained import setup (kept for skill portability)
# ============================================================
SKILL_ROOT = Path("/home/workdir/.grok/skills/mk2-metricforge-analyzer/scripts")
LANDMARK_ROOT = Path("/home/workdir/.grok/skills/landmark-provider/scripts")

for p in (str(SKILL_ROOT), str(LANDMARK_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

# Core dependencies with clear error messages
try:
    from landmark_provider import extract_landmarks
except ImportError as e:
    extract_landmarks = None
    print(f"[WARNING] landmark_provider not available: {e}")

try:
    from unified_body_analyzer import create_unified_analyzer
except ImportError as e:
    create_unified_analyzer = None
    print(f"[WARNING] unified_body_analyzer not available: {e}")

try:
    from mk2_precision_grok import create_mk2_grok
except ImportError as e:
    create_mk2_grok = None
    print(f"[WARNING] mk2_precision_grok not available: {e}")

try:
    from core.angle_calculator import create_angle_calculator
except ImportError as e:
    create_angle_calculator = None
    print(f"[WARNING] angle_calculator not available: {e}")

try:
    from mk2_metricforge_reporter import create_reporter
except ImportError as e:
    create_reporter = None
    print(f"[WARNING] mk2_metricforge_reporter not available: {e}")


class FullBodyAnalyzer:
    """
    Single entry point for full body + glute analysis.
    Supports real user-provided height_cm for accurate scaling of all metrics.
    """

    def __init__(self, height_cm: Optional[float] = None):
        self.height_cm = height_cm
        self.unified = create_unified_analyzer() if create_unified_analyzer else None
        self.mk2 = create_mk2_grok(height_cm=height_cm) if create_mk2_grok else None
        self.angle_calc = create_angle_calculator() if create_angle_calculator else None

        if height_cm is None:
            print("[INFO] No height_cm provided. Some metrics will use proportional estimation.")

    def analyze(self, image_path: str, height_cm: Optional[float] = None) -> Dict[str, Any]:
        """
        Main method. Runs the full pipeline.
        If height_cm is passed here, it overrides the one from __init__.
        """
        if height_cm is not None:
            self.height_cm = height_cm

        result = {
            "image_path": image_path,
            "height_cm_used": self.height_cm,
            "landmarks_extracted": False,
            "unified_analysis": None,
            "mk2_analysis": None,
            "glute_angles": None,
            "3d_proportions": None,
            "smplx_proxy": None,
            "report": None,
            "errors": []
        }

        # Step 1: Extract landmarks
        if extract_landmarks is None:
            result["errors"].append("Landmark Provider not available")
            return result

        try:
            lm_data = extract_landmarks(image_path)
            world_landmarks = lm_data.get("pose", {}).get("world_landmarks")
            landmarks = lm_data.get("pose", {}).get("landmarks")
            result["landmarks_extracted"] = True
            result["face_landmarks_available"] = bool(lm_data.get("face", {}).get("landmarks"))
        except Exception as e:
            result["errors"].append(f"Landmark extraction failed: {e}")
            return result

        # NEW: Face Identity Lock from facial landmarks (v1.0 integration)
        try:
            from face_identity_lock import get_face_identity_from_landmarks
            face_lock_result = get_face_identity_from_landmarks(lm_data)
            result["face_identity_lock"] = face_lock_result
        except Exception as e:
            result["face_identity_lock"] = {"error": str(e), "face_identity_lock_block": ""}

        # Step 2: Unified Analysis
        if self.unified and landmarks:
            try:
                unified_result = self.unified.analyze(landmarks, world_landmarks=world_landmarks)
                result["unified_analysis"] = self.unified.to_dict(unified_result) if hasattr(self.unified, "to_dict") else str(unified_result)
            except Exception as e:
                result["errors"].append(f"Unified analysis failed: {e}")

        # Step 3: MK2 Precision Grok
        if self.mk2 and landmarks:
            try:
                mk2_result = self.mk2.analyze(image_path, landmarks=landmarks, world_landmarks=world_landmarks)
                result["mk2_analysis"] = mk2_result.to_dict()
            except Exception as e:
                result["errors"].append(f"MK2 analysis failed: {e}")

        # Step 4: Full 3D Body Proportion Engine + SMPL-X Proxy + MetricForge
        if world_landmarks:
            try:
                # Full 3D Body Proportion Engine
                from full_3d_proportion_engine import create_full_3d_engine
                engine = create_full_3d_engine(height_cm=self.height_cm)
                three_d_result = engine.analyze(world_landmarks)
                result["3d_proportions"] = three_d_result

                # SMPL-X Proxy for enhanced volumetric metrics
                from smplx_proxy import create_smplx_proxy
                proxy = create_smplx_proxy()
                smplx_metrics = proxy.compute_enhanced_glute_metrics(world_landmarks, self.height_cm)
                result["smplx_proxy"] = smplx_metrics

                # MetricForge Glute Angles (enhanced with 3D + SMPL-X data)
                if self.angle_calc:
                    glute_result = self.angle_calc.calculate_all_glute_angles(
                        world_landmarks, use_world=True, normalize_view=True, three_d_data=three_d_result
                    )
                    result["glute_angles"] = {**glute_result, **smplx_metrics}
                else:
                    result["glute_angles"] = {**three_d_result.get("glute_metrics", {}), **smplx_metrics}
            except Exception as e:
                result["errors"].append(f"3D Engine / SMPL-X Proxy / MetricForge failed: {e}")
                result["3d_proportions"] = {"status": "fallback", "note": str(e)}

        # Step 5: Generate full 33-metric professional report (default)
        if create_reporter:
            try:
                reporter = create_reporter()
                # Prefer the new 33-metric report
                if hasattr(reporter, "generate_33_metric_report"):
                    result["report"] = reporter.generate_33_metric_report(
                        character_name="Analyzed Character",
                        height_cm=self.height_cm,
                        unified_data=result.get("unified_analysis"),
                        mk2_data=result.get("mk2_analysis"),
                        glute_angles=result.get("glute_angles"),
                        face_lock_data=result.get("face_identity_lock"),
                        three_d_data=result.get("3d_proportions"),
                        smplx_data=result.get("smplx_proxy"),
                        sources="Full landmark + 3D + SMPL-X analysis"
                    )
                else:
                    result["report"] = reporter.generate_report(
                        character_name="Analyzed Character",
                        height_cm=self.height_cm,
                        unified_data=result.get("unified_analysis"),
                        mk2_data=result.get("mk2_analysis"),
                        glute_angles=result.get("glute_angles"),
                        face_lock_data=result.get("face_identity_lock"),
                        sources="Full Body Analyzer + Landmark + 3D Engine"
                    )
            except Exception as e:
                result["errors"].append(f"Reporter failed: {e}")
                result["report"] = self._generate_simple_report(result)
        else:
            result["report"] = self._generate_simple_report(result)

        return result

    def _generate_simple_report(self, result: Dict) -> str:
        """Fallback simple report"""
        lines = [
            "# Full Body Analysis Report (Fallback)",
            "",
            f"**Image:** {result['image_path']}",
            ""
        ]
        if result.get("glute_angles"):
            lines.append("## Glute Angles available from MetricForge")
        if result.get("errors"):
            lines.append("## Errors")
            for err in result["errors"]:
                lines.append(f"- {err}")
        return "\n".join(lines)


def analyze_image(image_path: str, height_cm: Optional[float] = None) -> Dict[str, Any]:
    """
    Convenience function - the easiest way to run full analysis.
    Supports real_height_cm for proper metric scaling.
    """
    analyzer = FullBodyAnalyzer(height_cm=height_cm)
    return analyzer.analyze(image_path, height_cm=height_cm)


# ============================================================
# Basic CLI entry point
# ============================================================
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MK2 + MetricForge Full Body Analyzer")
    parser.add_argument("image_path", help="Path to input image")
    parser.add_argument("--height", type=float, default=None, help="Real height in cm (recommended)")
    args = parser.parse_args()

    print("=== Running Full Body Analysis (33-metric mode) ===")
    result = analyze_image(args.image_path, height_cm=args.height)

    if result.get("report"):
        print(result["report"])
    else:
        print("Analysis completed with errors.")
        for err in result.get("errors", []):
            print(f"  - {err}")