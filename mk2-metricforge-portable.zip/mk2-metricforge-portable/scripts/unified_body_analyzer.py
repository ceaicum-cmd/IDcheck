#!/usr/bin/env python3
"""
Unified Body Analyzer (minimal functional implementation for mk2-metricforge-analyzer)
Provides basic proportion calculations from MediaPipe landmarks + world_landmarks.
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List
import numpy as np

def create_unified_analyzer() -> "UnifiedBodyAnalyzer":
    return UnifiedBodyAnalyzer()

class UnifiedBodyAnalyzer:
    """
    Unified analyzer for body proportions.
    Computes shoulder, waist, hip estimates and basic ratios.
    """

    def __init__(self):
        self.version = "1.0-minimal"

    def analyze(self, landmarks: List[Dict], world_landmarks: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """
        Analyze pose landmarks.
        landmarks: list of dicts with x,y,visibility (image normalized 0-1)
        world_landmarks: list of dicts with x,y,z (meters)
        """
        result = {
            "status": "success",
            "version": self.version,
            "shoulder_width_px": 0.0,
            "hip_width_px": 0.0,
            "waist_estimate_px": 0.0,
            "body_ratios": {},
            "confidence": 0.7
        }

        if not landmarks or len(landmarks) < 25:
            result["status"] = "insufficient_landmarks"
            return result

        try:
            # MediaPipe pose indices (standard)
            # 11: left_shoulder, 12: right_shoulder
            # 23: left_hip, 24: right_hip
            # 25: left_knee, 26: right_knee

            lm = landmarks
            left_shoulder = lm[11]
            right_shoulder = lm[12]
            left_hip = lm[23]
            right_hip = lm[24]

            # Pixel-space approximations (assuming image normalized)
            shoulder_width = abs(left_shoulder.get("x", 0) - right_shoulder.get("x", 0))
            hip_width = abs(left_hip.get("x", 0) - right_hip.get("x", 0))

            result["shoulder_width_px"] = round(shoulder_width * 1000, 1)  # rough
            result["hip_width_px"] = round(hip_width * 1000, 1)

            # Simple waist estimate (mid between shoulders and hips, narrower)
            result["waist_estimate_px"] = round((shoulder_width + hip_width) / 2 * 0.65 * 1000, 1)

            result["body_ratios"] = {
                "shoulder_to_hip_ratio": round(shoulder_width / max(hip_width, 0.01), 3),
                "hip_to_shoulder_ratio": round(hip_width / max(shoulder_width, 0.01), 3),
            }

            if world_landmarks and len(world_landmarks) > 24:
                # Use world for better scale if available
                wlm = world_landmarks
                try:
                    ws = wlm[11]
                    wh = wlm[23]
                    world_hip_width = abs(ws.get("x", 0) - wh.get("x", 0))  # rough, actually different indices
                    result["world_hip_width_m"] = round(world_hip_width, 4)
                except Exception:
                    pass

        except Exception as e:
            result["status"] = "error"
            result["error"] = str(e)

        return result

    def to_dict(self, result: Dict[str, Any]) -> Dict[str, Any]:
        return result if isinstance(result, dict) else {"raw": str(result)}
