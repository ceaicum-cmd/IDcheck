#!/usr/bin/env python3
"""
Face Identity Lock Module v1.0
Uses facial landmarks (from MediaPipe Face Landmarker - 478 points)
to create precise, quantitative Face Identity descriptions
for Grok Imagine prompt engineering.

Integrated with mk2-metricforge-analyzer skill.
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional
import numpy as np


# ============================================================
# MediaPipe Face Landmarker 478-point key indices
# (selected most useful for identity locking)
# ============================================================

KEY_LANDMARKS = {
    # Face contour (for width and shape)
    "face_left": 234,
    "face_right": 454,
    "face_top": 10,
    "chin": 152,
    
    # Eyes
    "left_eye_left": 33,
    "left_eye_right": 133,
    "left_eye_top": 159,
    "left_eye_bottom": 145,
    "right_eye_left": 362,
    "right_eye_right": 263,
    "right_eye_top": 386,
    "right_eye_bottom": 374,
    
    # Eyebrows
    "left_eyebrow_inner": 70,
    "left_eyebrow_outer": 105,
    "right_eyebrow_inner": 300,
    "right_eyebrow_outer": 334,
    
    # Nose
    "nose_tip": 1,
    "nose_bridge_top": 168,
    "nose_left": 49,
    "nose_right": 279,
    
    # Lips
    "upper_lip_top": 13,
    "lower_lip_bottom": 14,
    "mouth_left": 61,
    "mouth_right": 291,
    "upper_lip_center": 0,
    "lower_lip_center": 17,
    
    # Additional landmarks for new metrics
    "left_cheek": 50,
    "right_cheek": 280,
    "jaw_left": 172,
    "jaw_right": 397,
}


def _get_landmark_coords(landmarks: List[Dict], index: int) -> np.ndarray:
    """Get [x, y, z] coordinates for a landmark index."""
    if index >= len(landmarks):
        return np.array([0.0, 0.0, 0.0])
    lm = landmarks[index]
    return np.array([lm.get('x', 0.0), lm.get('y', 0.0), lm.get('z', 0.0)])


def analyze_face_landmarks(face_landmarks: List[Dict]) -> Dict[str, Any]:
    """
    Analyze facial landmarks and compute identity-relevant metrics.
    Returns quantitative measurements + qualitative description.
    """
    if not face_landmarks or len(face_landmarks) < 400:
        return {
            "error": "Insufficient face landmarks (need ~478)",
            "face_identity_lock_block": ""
        }

    # Get key points
    face_left = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["face_left"])
    face_right = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["face_right"])
    face_top = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["face_top"])
    chin = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["chin"])
    
    left_eye_left = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eye_left"])
    left_eye_right = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eye_right"])
    right_eye_left = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["right_eye_left"])
    right_eye_right = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["right_eye_right"])
    
    nose_tip = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["nose_tip"])
    mouth_left = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["mouth_left"])
    mouth_right = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["mouth_right"])
    
    upper_lip = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["upper_lip_top"])
    lower_lip = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["lower_lip_bottom"])

    # === Compute metrics ===
    face_width = np.linalg.norm(face_right - face_left)
    face_height = np.linalg.norm(chin - face_top)
    fwhr = face_width / face_height if face_height > 0 else 0.0   # Facial Width-to-Height Ratio
    
    eye_width_left = np.linalg.norm(left_eye_right - left_eye_left)
    eye_width_right = np.linalg.norm(right_eye_right - right_eye_left)
    avg_eye_width = (eye_width_left + eye_width_right) / 2
    
    inter_eye_distance = np.linalg.norm(right_eye_left - left_eye_right)
    eye_separation_ratio = inter_eye_distance / face_width if face_width > 0 else 0.0
    
    # Eye Aspect Ratio (EAR) - important for eye shape
    left_ear = (np.linalg.norm(_get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eye_top"]) - 
                               _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eye_bottom"])) / 
                eye_width_left) if eye_width_left > 0 else 0.0
    right_ear = (np.linalg.norm(_get_landmark_coords(face_landmarks, KEY_LANDMARKS["right_eye_top"]) - 
                                _get_landmark_coords(face_landmarks, KEY_LANDMARKS["right_eye_bottom"])) / 
                 eye_width_right) if eye_width_right > 0 else 0.0
    avg_ear = (left_ear + right_ear) / 2
    
    mouth_width = np.linalg.norm(mouth_right - mouth_left)
    lip_height = np.linalg.norm(lower_lip - upper_lip)
    lip_ratio = lip_height / mouth_width if mouth_width > 0 else 0.0
    
    nose_width = np.linalg.norm(
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["nose_left"]) - 
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["nose_right"])
    )
    
    # Philtrum length (nose tip to upper lip center)
    philtrum = np.linalg.norm(nose_tip - upper_lip)
    
    # Jaw width (using jaw landmarks)
    jaw_width = np.linalg.norm(
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["jaw_left"]) -
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["jaw_right"])
    )
    jaw_taper_ratio = jaw_width / face_width if face_width > 0 else 0.0
    
    # Cheekbone prominence proxy (cheek to face width)
    left_cheek = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_cheek"])
    right_cheek = _get_landmark_coords(face_landmarks, KEY_LANDMARKS["right_cheek"])
    cheekbone_width = np.linalg.norm(right_cheek - left_cheek)
    cheekbone_prominence = cheekbone_width / face_width if face_width > 0 else 0.0
    
    # Eyebrow to eye distance ratio (for eyebrow position)
    left_brow_to_eye = np.linalg.norm(
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eyebrow_inner"]) -
        _get_landmark_coords(face_landmarks, KEY_LANDMARKS["left_eye_left"])
    )
    brow_eye_ratio = left_brow_to_eye / face_height if face_height > 0 else 0.0
    
    # Normalize some values relative to face width
    results = {
        "face_width_norm": round(face_width, 4),
        "face_height_norm": round(face_height, 4),
        "fwhr": round(fwhr, 3),
        "eye_separation_ratio": round(eye_separation_ratio, 3),
        "avg_eye_width_norm": round(avg_eye_width, 4),
        "avg_eye_aspect_ratio": round(avg_ear, 3),
        "mouth_width_norm": round(mouth_width, 4),
        "lip_height_norm": round(lip_height, 4),
        "lip_ratio": round(lip_ratio, 3),
        "nose_width_norm": round(nose_width, 4),
        "philtrum_length_norm": round(philtrum, 4),
        "jaw_width_norm": round(jaw_width, 4),
        "jaw_taper_ratio": round(jaw_taper_ratio, 3),
        "cheekbone_prominence": round(cheekbone_prominence, 3),
        "brow_eye_ratio": round(brow_eye_ratio, 3),
        "num_landmarks_used": len(face_landmarks),
    }
    
    # === Generate strong Identity Lock text block ===
    # Version 1: Standard (good balance between detail and flexibility)
    standard_lock = f"""exact same face across generations, preserve exact facial identity from reference: 
soft balanced oval face shape (FWHR {fwhr:.2f}), 
large expressive almond-shaped eyes with natural spacing (eye separation {eye_separation_ratio:.2f}, EAR {avg_ear:.2f}), 
delicately arched eyebrows, small straight refined nose, 
full natural lips (lip ratio {lip_ratio:.2f}), 
gentle feminine jawline with soft cheekbones, 
long glossy warm brown hair with natural movement, 
innocent gentle expression, realistic fair skin with natural texture, 
identity locked face exactly, no face morphing"""

    # Version 2: Strict (maximum identity lock - recommended for consistent character)
    strict_lock = f"""STRICT FACE IDENTITY LOCK - preserve this exact face in every generation with zero deviation: 
face shape: soft oval, balanced proportions (FWHR {fwhr:.2f}), 
eyes: large expressive almond shape, natural eye separation ratio {eye_separation_ratio:.2f}, natural eye aspect ratio {avg_ear:.2f}, 
eyebrows: delicately arched and well positioned, 
nose: small, straight, refined, 
lips: full natural shape with balanced lip ratio {lip_ratio:.2f}, 
jawline: gentle and feminine with soft cheekbones, 
hair: long glossy warm brown with natural flow, 
expression: innocent, gentle, slightly playful, 
skin: realistic fair tone with natural subtle texture and pores, 
DO NOT change eye shape, eye size, nose shape, lip fullness, jawline, or overall face structure. 
Face must remain identical to reference across all images and videos."""

    results["face_identity_lock_block"] = standard_lock.strip()
    results["face_identity_lock_block_strict"] = strict_lock.strip()
    results["recommended_lock_block"] = strict_lock.strip()  # Default recommendation
    
    return results


def create_face_identity_lock_prompt(face_landmarks: Optional[List[Dict]] = None, 
                                     visual_description: str = "",
                                     strict: bool = True) -> str:
    """
    Main entry point for getting a Face Identity Lock prompt block.
    
    Args:
        face_landmarks: List of facial landmarks from MediaPipe
        visual_description: Fallback text description if no landmarks
        strict: If True, returns the strict maximum-lock version (recommended)
    """
    if face_landmarks:
        analysis = analyze_face_landmarks(face_landmarks)
        if "error" not in analysis:
            if strict:
                return analysis.get("face_identity_lock_block_strict", 
                                   analysis.get("recommended_lock_block", ""))
            else:
                return analysis.get("face_identity_lock_block", "")
    
    # Fallback
    if visual_description:
        base = f"exact same face: {visual_description}, preserve exact facial features"
    else:
        base = "exact same face as the locked identity, soft oval feminine face, large expressive eyes, full natural lips"
    
    if strict:
        return base + ", identity locked face exactly with zero deviation, no face morphing allowed"
    else:
        return base + ", identity locked face exactly, no face morphing"


# Helper for integration with full_body_analyzer
def get_face_identity_from_landmarks(landmark_data: Dict) -> Dict[str, Any]:
    """Convenience function to be called from the main analyzer."""
    face_lms = landmark_data.get("face", {}).get("landmarks", [])
    if face_lms:
        return analyze_face_landmarks(face_lms)
    return {
        "face_identity_lock_block": "",
        "face_identity_lock_block_strict": "",
        "recommended_lock_block": "",
        "note": "No face landmarks available"
    }


def fuse_face_identities(face_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Simple fusion for multiple images (Improvement 5).
    Averages key numeric metrics and keeps the best lock block.
    """
    if not face_results:
        return {"error": "No face results to fuse"}

    valid = [r for r in face_results if "error" not in r and r.get("fwhr")]

    if not valid:
        return {"error": "No valid face results for fusion"}

    fused = {}
    keys_to_average = [
        "fwhr", "eye_separation_ratio", "avg_eye_aspect_ratio",
        "lip_ratio", "jaw_taper_ratio", "cheekbone_prominence"
    ]

    for key in keys_to_average:
        values = [r[key] for r in valid if key in r]
        if values:
            fused[key] = round(sum(values) / len(values), 3)

    # Take the lock block from the first valid result (or could pick best)
    fused["face_identity_lock_block"] = valid[0].get("face_identity_lock_block", "")
    fused["fusion_note"] = f"Fused from {len(valid)} images using average of key metrics"
    fused["num_sources"] = len(valid)

    return fused