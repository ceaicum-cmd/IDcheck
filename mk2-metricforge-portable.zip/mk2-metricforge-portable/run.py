#!/usr/bin/env python3
"""
Portable entry point for MK2 + MetricForge 33-metric analyzer.
"""

import sys
from pathlib import Path

# Add local scripts to path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "landmark-provider" / "scripts"))

from full_body_analyzer import analyze_image

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MK2 + MetricForge 33-Metric Body Analyzer (Portable)")
    parser.add_argument("image_path", help="Path to the input image")
    parser.add_argument("--height", type=float, default=None, help="Real height in cm (strongly recommended)")
    args = parser.parse_args()

    print("=== MK2 + MetricForge Portable v2 ===")
    print(f"Analyzing: {args.image_path}")
    if args.height:
        print(f"Using real height: {args.height} cm")

    result = analyze_image(args.image_path, height_cm=args.height)

    print("\n" + "="*70)
    if result.get("report"):
        print(result["report"])
    else:
        print("Analysis completed.")
        if result.get("errors"):
            print("\nErrors/Warnings:")
            for e in result["errors"]:
                print(f"  - {e}")
    print("="*70)