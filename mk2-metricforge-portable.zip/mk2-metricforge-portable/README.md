# MK2 + MetricForge Portable v2

Self-contained, production-ready body measurement pipeline with **33 curve-focused metrics**.

This package removes most hardcoded paths from the original Grok skill and can be run independently.

## Installation

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

**Note:** MediaPipe will download its models on first run (~100-200MB).

## Usage

### Command Line

```bash
python run.py path/to/your/image.jpg --height 155.0
```

### Python API

```python
from scripts.full_body_analyzer import analyze_image

result = analyze_image("photo.jpg", height_cm=155.0)
print(result["report"])
```

## Output

You get a professional **33-metric report** including:
- Detailed linear, depth, projection, angle, and ratio metrics
- Strong S-curve and glute shelf analysis
- Ready-to-use Identity Lock block for Grok Imagine / video templates

## Configuration (Optional)

You can set environment variables for model paths if needed:

```bash
export MEDIAPIPE_POSE_MODEL_PATH=/path/to/pose.task
export MEDIAPIPE_FACE_MODEL_PATH=/path/to/face.task
```

## Differences from Original Skill

- No hardcoded `/home/workdir/.grok/skills/...` paths
- Cleaner package structure
- Full 33-metric report by default
- Proper `height_cm` scaling
- Basic CLI included
- Easier to integrate into your own projects

## Notes

- For maximum accuracy, provide `--height` (real height in cm).
- The system works best with clear full-body or 3/4 pose photos.
- This is the cleaned, portable version of the pipeline we developed together.

Enjoy creating consistent, high-quality character body data!